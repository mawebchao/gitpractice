create view emp_view as
select `cgb2107`.`emp`.`empno`    AS `empno`,
       `cgb2107`.`emp`.`ename`    AS `ename`,
       `cgb2107`.`emp`.`job`      AS `job`,
       `cgb2107`.`emp`.`mgr`      AS `mgr`,
       `cgb2107`.`emp`.`hiredate` AS `hiredate`,
       `cgb2107`.`emp`.`sal`      AS `sal`,
       `cgb2107`.`emp`.`comm`     AS `comm`,
       `cgb2107`.`emp`.`deptno`   AS `deptno`
from `cgb2107`.`emp`
where `cgb2107`.`emp`.`ename` like '%a%';

