package com.stepfive.service;

import com.stepfive.pojo.Order;

public interface OrderService {
    void create(Order order);
}
