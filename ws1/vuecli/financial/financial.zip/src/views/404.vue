<template>
    <div>
        页面走丢了
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>

</style>