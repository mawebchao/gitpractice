<template>
    <div>
        <h1>我是审核中页面</h1>
    </div>
</template>

<script>
    export default {
        mounted(){
            console.log("tabs2重复渲染了")
        }
    }
</script>

<style lang="less" scoped>

</style>